import process from "node:process";

import XLSX from "xlsx";

const SOURCE_NAME = "LGD Telangana source workbooks";
const SOURCE_REFERENCE = "Registrar General of India Local Government Directory (LGD)";
const CEO_SOURCE = "CEO Telangana";
const CEO_REFERENCE = "https://ceotelangana.nic.in/";

function argumentsFrom(argv) {
  const values = new Map();

  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];

    if (token.startsWith("--")) {
      const following = argv[index + 1];
      if (!following || following.startsWith("--")) {
        values.set(token, true);
      } else {
        values.set(token, following);
        index += 1;
      }
    }
  }

  return values;
}

function requiredArgument(args, name) {
  const value = args.get(name);
  if (!value || value === true) {
    throw new Error(`${name} is required`);
  }
  return value;
}

function text(value) {
  if (value === null || value === undefined || value === "") return null;
  return String(value).trim();
}

function code(value) {
  const valueText = text(value);
  if (!valueText) return null;
  return valueText.replace(/\.0$/, "");
}

function normalizedName(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/^\s*\d+\s*-\s*/, "")
    .replace(/[^a-z0-9]+/g, "");
}

function readSheet(file, sheetName) {
  const workbook = XLSX.readFile(file, {
    cellDates: false,
    raw: true
  });
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) throw new Error(`Missing sheet ${sheetName} in ${file}`);
  return XLSX.utils.sheet_to_json(sheet, { defval: null, raw: true });
}

function uniqueRows(rows, keyName) {
  const output = new Map();
  for (const row of rows) {
    const rowCode = code(row[keyName]);
    if (!rowCode) throw new Error(`Missing ${keyName}`);
    if (!output.has(rowCode)) output.set(rowCode, row);
  }
  return output;
}

function groupRows(rows, keyName) {
  const output = new Map();
  for (const row of rows) {
    const rowCode = code(row[keyName]);
    if (!rowCode) continue;
    const group = output.get(rowCode) || [];
    group.push(row);
    output.set(rowCode, group);
  }
  return output;
}

function assertCount(label, actual, expected) {
  if (actual !== expected) {
    throw new Error(`${label}: expected ${expected}, found ${actual}`);
  }
}

function loadSources(adminFile, localBodyFile) {
  const administrativeRows = readSheet(adminFile, "Administrative Hierarchy");
  const zillaParishads = readSheet(localBodyFile, "Zilla_Parishad");
  const mandalParishads = readSheet(localBodyFile, "Mandal_Parishad");
  const gramPanchayats = readSheet(localBodyFile, "Gram_Panchayat");
  const gpVillages = readSheet(localBodyFile, "GP_Villages");
  const urbanBodies = readSheet(localBodyFile, "Urban_Local_Body");
  const urbanWards = readSheet(localBodyFile, "ULB_Wards");

  const sources = {
    administrativeRows,
    states: uniqueRows(administrativeRows, "State_Code"),
    districts: uniqueRows(administrativeRows, "District_Code"),
    mandals: uniqueRows(administrativeRows, "Mandal_Code"),
    villages: uniqueRows(administrativeRows, "Village_Code"),
    zillaParishads: uniqueRows(zillaParishads, "District_Code"),
    mandalParishads: uniqueRows(mandalParishads, "Mandal_Code"),
    gramPanchayatRows: gramPanchayats,
    gramPanchayats: uniqueRows(gramPanchayats, "Gram_Panchayat_Code"),
    gramPanchayatGroups: groupRows(gramPanchayats, "Gram_Panchayat_Code"),
    gpVillages,
    urbanBodies: uniqueRows(urbanBodies, "ULB_Code"),
    urbanWards: uniqueRows(urbanWards, "Ward_Code")
  };

  assertCount("States", sources.states.size, 1);
  assertCount("Districts", sources.districts.size, 33);
  assertCount("Mandals", sources.mandals.size, 621);
  assertCount("Villages", sources.villages.size, 11443);
  assertCount("Zilla Parishads", sources.zillaParishads.size, 33);
  assertCount("Mandal Parishads", sources.mandalParishads.size, 621);
  assertCount("Gram Panchayat source rows", gramPanchayats.length, 8409);
  assertCount("Unique Gram Panchayats", sources.gramPanchayats.size, 8366);
  assertCount("Urban local bodies", sources.urbanBodies.size, 161);
  assertCount("Urban wards", sources.urbanWards.size, 3453);

  return sources;
}

async function findGeography(db, record) {
  const result = await db.query(
    `
      SELECT id, code
      FROM geo_units
      WHERE geo_type = $1
        AND is_active = true
        AND (
          ($2::text IS NOT NULL AND lgd_code = $2)
          OR ($3::text IS NOT NULL AND code = $3)
          OR (
            parent_id IS NOT DISTINCT FROM $4::uuid
            AND regexp_replace(lower(name), '[^a-z0-9]+', '', 'g') = $5
          )
        )
      ORDER BY
        CASE WHEN lgd_code = $2 THEN 0 WHEN code = $3 THEN 1 ELSE 2 END
      LIMIT 1
      FOR UPDATE
    `,
    [record.geoType, record.lgdCode, record.code, record.parentId, normalizedName(record.name)]
  );
  return result.rows[0] || null;
}

async function upsertGeography(db, record) {
  const existing = await findGeography(db, record);
  const metadata = JSON.stringify(record.metadata || {});

  if (existing) {
    const result = await db.query(
      `
        UPDATE geo_units
        SET parent_id = $2,
            name = $3,
            name_local = $4,
            code = COALESCE(code, $5),
            state_code = $6,
            district_code = $7,
            urban_rural = COALESCE(urban_rural, $8),
            census_code = $9,
            lgd_code = $10,
            source_name = $11,
            source_reference = $12,
            verification_status = $13,
            metadata = metadata || $14::jsonb,
            is_active = true,
            updated_at = now()
        WHERE id = $1
        RETURNING id
      `,
      [
        existing.id, record.parentId, record.name, record.nameLocal, record.code,
        record.stateCode, record.districtCode, record.urbanRural,
        record.censusCode, record.lgdCode, SOURCE_NAME, SOURCE_REFERENCE,
        record.verificationStatus, metadata
      ]
    );
    return result.rows[0].id;
  }

  const result = await db.query(
    `
      INSERT INTO geo_units (
        parent_id, name, name_local, geo_type, code, state_code,
        district_code, urban_rural, census_code, lgd_code,
        source_name, source_reference, verification_status, metadata
      ) VALUES (
        $1, $2, $3, $4, $5, $6,
        $7, $8, $9, $10,
        $11, $12, $13, $14::jsonb
      )
      RETURNING id
    `,
    [
      record.parentId, record.name, record.nameLocal, record.geoType, record.code,
      record.stateCode, record.districtCode, record.urbanRural,
      record.censusCode, record.lgdCode, SOURCE_NAME, SOURCE_REFERENCE,
      record.verificationStatus, metadata
    ]
  );
  return result.rows[0].id;
}

async function upsertLocalBody(db, record) {
  const existing = await db.query(
    `SELECT id FROM local_bodies WHERE body_type = $1 AND code = $2 LIMIT 1 FOR UPDATE`,
    [record.bodyType, record.code]
  );
  const metadata = JSON.stringify(record.metadata || {});

  if (existing.rows[0]) {
    const result = await db.query(
      `
        UPDATE local_bodies
        SET parent_local_body_id = $2,
            name = $3,
            governance_level = $4,
            source_name = $5,
            source_reference = $6,
            verification_status = $7,
            metadata = metadata || $8::jsonb,
            is_active = true,
            updated_at = now()
        WHERE id = $1
        RETURNING id
      `,
      [
        existing.rows[0].id, record.parentId, record.name, record.governanceLevel,
        SOURCE_NAME, SOURCE_REFERENCE, record.verificationStatus, metadata
      ]
    );
    return result.rows[0].id;
  }

  const result = await db.query(
    `
      INSERT INTO local_bodies (
        parent_local_body_id, name, code, body_type, governance_level,
        source_name, source_reference, verification_status, metadata
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9::jsonb)
      RETURNING id
    `,
    [
      record.parentId, record.name, record.code, record.bodyType,
      record.governanceLevel, SOURCE_NAME, SOURCE_REFERENCE,
      record.verificationStatus, metadata
    ]
  );
  return result.rows[0].id;
}

async function upsertArea(db, record) {
  const existing = await db.query(
    `
      SELECT id
      FROM local_body_electoral_areas
      WHERE local_body_id = $1 AND area_type = $2 AND code = $3
      LIMIT 1 FOR UPDATE
    `,
    [record.localBodyId, record.areaType, record.code]
  );
  const metadata = JSON.stringify(record.metadata || {});

  if (existing.rows[0]) {
    const result = await db.query(
      `
        UPDATE local_body_electoral_areas
        SET name = $2,
            contested_office_type = $3,
            display_label = $4,
            source_name = $5,
            source_reference = $6,
            verification_status = $7,
            metadata = metadata || $8::jsonb,
            is_active = true,
            updated_at = now()
        WHERE id = $1
        RETURNING id
      `,
      [
        existing.rows[0].id, record.name, record.officeType, record.displayLabel,
        SOURCE_NAME, SOURCE_REFERENCE, record.verificationStatus, metadata
      ]
    );
    return result.rows[0].id;
  }

  const result = await db.query(
    `
      INSERT INTO local_body_electoral_areas (
        local_body_id, name, code, area_type, contested_office_type,
        display_label, source_name, source_reference, verification_status, metadata
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10::jsonb)
      RETURNING id
    `,
    [
      record.localBodyId, record.name, record.code, record.areaType,
      record.officeType, record.displayLabel, SOURCE_NAME, SOURCE_REFERENCE,
      record.verificationStatus, metadata
    ]
  );
  return result.rows[0].id;
}

async function upsertMapping(db, table, ownerColumn, ownerId, geoId, record) {
  const allowed = {
    local_body_geo_mapping: "local_body_id",
    local_body_area_geo_mapping: "electoral_area_id"
  };
  if (allowed[table] !== ownerColumn) throw new Error("Invalid mapping target");

  const existing = await db.query(
    `SELECT id FROM ${table} WHERE ${ownerColumn} = $1 AND geo_unit_id = $2 AND is_active = true LIMIT 1 FOR UPDATE`,
    [ownerId, geoId]
  );

  if (existing.rows[0]) {
    await db.query(
      `
        UPDATE ${table}
        SET coverage_type = $2,
            mapping_method = $3,
            confidence = $4,
            source_name = $5,
            source_reference = $6,
            verification_status = $7,
            notes = $8,
            updated_at = now()
        WHERE id = $1
      `,
      [
        existing.rows[0].id, record.coverageType, record.mappingMethod,
        record.confidence, SOURCE_NAME, SOURCE_REFERENCE,
        record.verificationStatus, record.notes
      ]
    );
    return;
  }

  await db.query(
    `
      INSERT INTO ${table} (
        ${ownerColumn}, geo_unit_id, coverage_type, mapping_method, confidence,
        source_name, source_reference, verification_status, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `,
    [
      ownerId, geoId, record.coverageType, record.mappingMethod,
      record.confidence, SOURCE_NAME, SOURCE_REFERENCE,
      record.verificationStatus, record.notes
    ]
  );
}

async function importAdministrative(db, sources) {
  const ids = { districts: new Map(), mandals: new Map(), villages: new Map() };
  const stateRow = [...sources.states.values()][0];
  const stateId = await upsertGeography(db, {
    parentId: null,
    name: text(stateRow.State_Name),
    nameLocal: null,
    geoType: "STATE",
    code: "TG",
    stateCode: "TG",
    districtCode: null,
    urbanRural: "MIXED",
    censusCode: null,
    lgdCode: code(stateRow.State_Code),
    verificationStatus: "SOURCE_VERIFIED",
    metadata: { lgd_state_code: code(stateRow.State_Code) }
  });

  for (const [districtCode, row] of sources.districts) {
    const id = await upsertGeography(db, {
      parentId: stateId,
      name: text(row.District_Name),
      nameLocal: text(row.District_Name_Telugu),
      geoType: "DISTRICT",
      code: districtCode,
      stateCode: "TG",
      districtCode,
      urbanRural: "MIXED",
      censusCode: null,
      lgdCode: districtCode,
      verificationStatus: "SOURCE_VERIFIED",
      metadata: {}
    });
    ids.districts.set(districtCode, id);
  }

  for (const [mandalCode, row] of sources.mandals) {
    const districtCode = code(row.District_Code);
    const id = await upsertGeography(db, {
      parentId: ids.districts.get(districtCode),
      name: text(row.Mandal_Name),
      nameLocal: text(row.Mandal_Name_Telugu),
      geoType: "MANDAL",
      code: mandalCode,
      stateCode: "TG",
      districtCode,
      urbanRural: null,
      censusCode: null,
      lgdCode: mandalCode,
      verificationStatus: "SOURCE_VERIFIED",
      metadata: {}
    });
    ids.mandals.set(mandalCode, id);
  }

  let processed = 0;
  for (const [villageCode, row] of sources.villages) {
    const districtCode = code(row.District_Code);
    const mandalCode = code(row.Mandal_Code);
    const id = await upsertGeography(db, {
      parentId: ids.mandals.get(mandalCode),
      name: text(row.Village_Name),
      nameLocal: text(row.Village_Name_Telugu),
      geoType: "VILLAGE",
      code: villageCode,
      stateCode: "TG",
      districtCode,
      urbanRural: null,
      censusCode: code(row.Census_2011_Code),
      lgdCode: villageCode,
      verificationStatus: "SOURCE_VERIFIED",
      metadata: {
        habitation_status: text(row.Habitation_Status),
        census_2001_code: code(row.Census_2001_Code)
      }
    });
    ids.villages.set(villageCode, id);
    processed += 1;
    if (processed % 1000 === 0) console.log(`Administrative villages: ${processed}/11443`);
  }

  return { stateId, ...ids };
}

async function importLocalBodies(db, sources, geoIds) {
  const bodyIds = {
    zillaParishads: new Map(), mandalParishads: new Map(),
    gramPanchayats: new Map(), urbanBodies: new Map()
  };
  const gpAreaIds = new Map();
  const wardAreaIds = new Map();

  for (const [districtCode, row] of sources.zillaParishads) {
    const bodyId = await upsertLocalBody(db, {
      parentId: null,
      name: text(row.Zilla_Parishad_Name),
      code: districtCode,
      bodyType: "ZILLA_PARISHAD",
      governanceLevel: "DISTRICT",
      verificationStatus: "DERIVED_REVIEW_REQUIRED",
      metadata: { district_code: districtCode, derived_from: "District" }
    });
    bodyIds.zillaParishads.set(districtCode, bodyId);
    await upsertMapping(db, "local_body_geo_mapping", "local_body_id", bodyId, geoIds.districts.get(districtCode), {
      coverageType: "FULL", mappingMethod: "DERIVED_FROM_ADMIN",
      confidence: 1, verificationStatus: "DERIVED_REVIEW_REQUIRED",
      notes: "One Zilla Parishad per source district; no separate ZP code was supplied."
    });
  }

  for (const [mandalCode, row] of sources.mandalParishads) {
    const districtCode = code(row.District_Code);
    const bodyId = await upsertLocalBody(db, {
      parentId: bodyIds.zillaParishads.get(districtCode),
      name: text(row.Mandal_Parishad_Name),
      code: mandalCode,
      bodyType: "MANDAL_PRAJA_PARISHAD",
      governanceLevel: "INTERMEDIATE",
      verificationStatus: "DERIVED_REVIEW_REQUIRED",
      metadata: { district_code: districtCode, mandal_code: mandalCode, derived_from: "Mandal" }
    });
    bodyIds.mandalParishads.set(mandalCode, bodyId);
    await upsertMapping(db, "local_body_geo_mapping", "local_body_id", bodyId, geoIds.mandals.get(mandalCode), {
      coverageType: "FULL", mappingMethod: "DERIVED_FROM_ADMIN",
      confidence: 1, verificationStatus: "DERIVED_REVIEW_REQUIRED",
      notes: "One Mandal Praja Parishad per source mandal; no separate MPP code was supplied."
    });
  }

  for (const [gpCode, row] of sources.gramPanchayats) {
    const group = sources.gramPanchayatGroups.get(gpCode);
    const mandalCodes = [...new Set(group.map(item => code(item.Mandal_Code)))];
    const ambiguousParent = mandalCodes.length !== 1;
    const bodyId = await upsertLocalBody(db, {
      parentId: ambiguousParent ? null : bodyIds.mandalParishads.get(mandalCodes[0]),
      name: text(row.Gram_Panchayat_Name),
      code: gpCode,
      bodyType: "GRAM_PANCHAYAT",
      governanceLevel: "VILLAGE",
      verificationStatus: ambiguousParent ? "REVIEW_REQUIRED" : "SOURCE_VERIFIED",
      metadata: {
        source_row_count: group.length,
        mandal_codes: mandalCodes,
        duplicate_code_across_mandals: ambiguousParent
      }
    });
    bodyIds.gramPanchayats.set(gpCode, bodyId);
    const areaId = await upsertArea(db, {
      localBodyId: bodyId,
      name: text(row.Gram_Panchayat_Name),
      code: gpCode,
      areaType: "GRAM_PANCHAYAT_AREA",
      officeType: "SARPANCH",
      displayLabel: "Gram Panchayat",
      verificationStatus: ambiguousParent ? "REVIEW_REQUIRED" : "SOURCE_VERIFIED",
      metadata: { mandal_codes: mandalCodes }
    });
    gpAreaIds.set(gpCode, areaId);

    for (const mandalCode of mandalCodes) {
      const mandalId = geoIds.mandals.get(mandalCode);
      if (!mandalId) throw new Error(`Unresolved mandal ${mandalCode} for GP ${gpCode}`);
      await upsertMapping(db, "local_body_geo_mapping", "local_body_id", bodyId, mandalId, {
        coverageType: "PARTIAL",
        mappingMethod: "SOURCE_DEFINED",
        confidence: 1,
        verificationStatus: ambiguousParent ? "REVIEW_REQUIRED" : "SOURCE_VERIFIED",
        notes: ambiguousParent
          ? "The same GP code occurs under multiple mandal groupings in the source."
          : "Gram Panchayat is linked to its source mandal."
      });
    }
  }

  let missingGpMappings = 0;
  for (const row of sources.gpVillages) {
    const gpCode = code(row.Gram_Panchayat_Code);
    const villageCode = code(row.Village_Code);
    if (!gpCode) {
      missingGpMappings += 1;
      continue;
    }
    const bodyId = bodyIds.gramPanchayats.get(gpCode);
    const areaId = gpAreaIds.get(gpCode);
    const villageId = geoIds.villages.get(villageCode);
    if (!bodyId || !areaId || !villageId) {
      throw new Error(`Unresolved GP/village mapping ${gpCode}/${villageCode}`);
    }
    const mapping = {
      coverageType: "FULL", mappingMethod: "SOURCE_DEFINED", confidence: 1,
      verificationStatus: "SOURCE_VERIFIED", notes: null
    };
    await upsertMapping(db, "local_body_geo_mapping", "local_body_id", bodyId, villageId, mapping);
    await upsertMapping(db, "local_body_area_geo_mapping", "electoral_area_id", areaId, villageId, mapping);
  }

  for (const [ulbCode, row] of sources.urbanBodies) {
    const corporation = text(row.ULB_Type) === "Municipal Corporation";
    const note = text(row.Mapping_Note);
    const bodyId = await upsertLocalBody(db, {
      parentId: null,
      name: text(row.ULB_Name),
      code: ulbCode,
      bodyType: corporation ? "MUNICIPAL_CORPORATION" : "MUNICIPALITY",
      governanceLevel: "URBAN",
      verificationStatus: note ? "REVIEW_REQUIRED" : "SOURCE_VERIFIED",
      metadata: {
        district_code: code(row.District_Code),
        mandal_code: code(row.Mandal_Code),
        mapping_note: note
      }
    });
    bodyIds.urbanBodies.set(ulbCode, bodyId);
    const mandalId = geoIds.mandals.get(code(row.Mandal_Code));
    if (mandalId) {
      await upsertMapping(db, "local_body_geo_mapping", "local_body_id", bodyId, mandalId, {
        coverageType: "PARTIAL",
        mappingMethod: note ? "NAME_INFERRED" : "SOURCE_DEFINED",
        confidence: note ? 0.75 : 1,
        verificationStatus: note ? "REVIEW_REQUIRED" : "SOURCE_VERIFIED",
        notes: note
      });
    }
  }

  for (const [wardCode, row] of sources.urbanWards) {
    const ulbCode = code(row.ULB_Code);
    const bodyId = bodyIds.urbanBodies.get(ulbCode);
    if (!bodyId) throw new Error(`Unresolved ULB for ward ${wardCode}`);
    const corporation = text(row.ULB_Type) === "Municipal Corporation";
    const areaId = await upsertArea(db, {
      localBodyId: bodyId,
      name: text(row.Ward_Name),
      code: wardCode,
      areaType: "URBAN_WARD",
      officeType: corporation ? "CORPORATOR" : "COUNCILLOR",
      displayLabel: corporation ? "Division" : "Ward",
      verificationStatus: "SOURCE_VERIFIED",
      metadata: { district_code: code(row.District_Code), mandal_code: code(row.Mandal_Code) }
    });
    wardAreaIds.set(wardCode, areaId);
    const mandalId = geoIds.mandals.get(code(row.Mandal_Code));
    if (mandalId) {
      await upsertMapping(db, "local_body_area_geo_mapping", "electoral_area_id", areaId, mandalId, {
        coverageType: "PARTIAL", mappingMethod: "SOURCE_DEFINED", confidence: 1,
        verificationStatus: "SOURCE_VERIFIED",
        notes: "Ward is linked to its source mandal; finer village extent was not supplied."
      });
      await upsertMapping(db, "local_body_geo_mapping", "local_body_id", bodyId, mandalId, {
        coverageType: "PARTIAL", mappingMethod: "SOURCE_DEFINED", confidence: 1,
        verificationStatus: "SOURCE_VERIFIED",
        notes: "ULB-to-mandal relationship is supported by a supplied ward row."
      });
    }
  }

  return { bodyIds, gpAreaIds, wardAreaIds, missingGpMappings };
}

const assemblyNames = [
  "Sirpur", "Chennur", "Bellampalli", "Mancherial", "Asifabad", "Khanapur", "Adilabad", "Boath", "Nirmal", "Mudhole",
  "Armur", "Bodhan", "Jukkal", "Banswada", "Yellareddy", "Kamareddy", "Nizamabad (Urban)", "Nizamabad (Rural)", "Balkonda",
  "Koratla", "Jagtial", "Dharmapuri", "Ramagundam", "Manthani", "Peddapalle", "Karimnagar", "Choppadandi", "Vemulawada", "Sircilla", "Manakondur", "Huzurabad", "Husnabad",
  "Siddipet", "Medak", "Narayankhed", "Andole", "Narsapur", "Zahirabad", "Sangareddy", "Patancheru", "Dubbak", "Gajwel",
  "Medchal", "Malkajgiri", "Quthbullapur", "Kukatpally", "Uppal", "Ibrahimpatnam", "Lal Bahadur Nagar", "Maheshwaram", "Rajendranagar", "Serilingampally", "Chevella", "Pargi", "Vikarabad", "Tandur",
  "Musheerabad", "Malakpet", "Amberpet", "Khairatabad", "Jubilee Hills", "Sanathnagar", "Nampally", "Karwan", "Goshamahal", "Charminar", "Chandrayangutta", "Yakutpura", "Bahadurpura", "Secunderabad", "Secunderabad Cantt.",
  "Kodangal", "Narayanpet", "Mahbubnagar", "Jadcherla", "Devarkadra", "Makthal", "Wanaparthy", "Gadwal", "Alampur", "Nagarkurnool", "Achampet", "Kalwakurthy", "Shadnagar", "Kollapur",
  "Devarakonda", "Nagarjuna Sagar", "Miryalaguda", "Huzurnagar", "Kodad", "Suryapet", "Nalgonda", "Munugode", "Bhongir", "Nakrekal", "Thungathurthi", "Alair",
  "Jangaon", "Ghanpur (Station)", "Palakurthi", "Dornakal", "Mahabubabad", "Narsampet", "Parkal", "Warangal West", "Warangal East", "Wardhannapet", "Bhupalpalle", "Mulug",
  "Pinapaka", "Yellandu", "Khammam", "Palair", "Madhira", "Wyra", "Sathupalle", "Kothagudem", "Aswaraopeta", "Bhadrachalam"
];

const scAssembly = new Set([2, 3, 13, 22, 27, 30, 36, 38, 53, 55, 71, 80, 82, 95, 96, 99, 107, 114, 116]);
const stAssembly = new Set([5, 6, 8, 86, 101, 102, 109, 110, 111, 115, 118, 119]);

const parliamentaryDefinitions = [
  [1, "Adilabad", "ST", [1, 5, 6, 7, 8, 9, 10]], [2, "Peddapalle", "SC", [2, 3, 4, 22, 23, 24, 25]],
  [3, "Karimnagar", "GENERAL", [26, 27, 28, 29, 30, 31, 32]], [4, "Nizamabad", "GENERAL", [11, 12, 17, 18, 19, 20, 21]],
  [5, "Zahirabad", "GENERAL", [13, 14, 15, 16, 35, 36, 38]], [6, "Medak", "GENERAL", [33, 34, 37, 39, 40, 41, 42]],
  [7, "Malkajgiri", "GENERAL", [43, 44, 45, 46, 47, 49, 71]], [8, "Secunderabad", "GENERAL", [57, 59, 60, 61, 62, 63, 70]],
  [9, "Hyderabad", "GENERAL", [58, 64, 65, 66, 67, 68, 69]], [10, "Chevella", "GENERAL", [50, 51, 52, 53, 54, 55, 56]],
  [11, "Mahbubnagar", "GENERAL", [72, 73, 74, 75, 76, 77, 84]], [12, "Nagarkurnool", "SC", [78, 79, 80, 81, 82, 83, 85]],
  [13, "Nalgonda", "GENERAL", [86, 87, 88, 89, 90, 91, 92]], [14, "Bhongir", "GENERAL", [48, 93, 94, 95, 96, 97, 98]],
  [15, "Warangal", "SC", [99, 100, 104, 105, 106, 107, 108]], [16, "Mahabubabad", "ST", [101, 102, 103, 109, 110, 111, 119]],
  [17, "Khammam", "GENERAL", [112, 113, 114, 115, 116, 117, 118]]
];

const mlcDefinitions = [
  ["MLC-LA-MBNR", "Mahbubnagar Local Authorities", "MLC_LOCAL_AUTHORITIES", "Mahbubnagar", 2],
  ["MLC-LA-RR", "Ranga Reddy Local Authorities", "MLC_LOCAL_AUTHORITIES", "Ranga Reddy", 2],
  ["MLC-LA-HYD", "Hyderabad Local Authorities", "MLC_LOCAL_AUTHORITIES", "Hyderabad", 2],
  ["MLC-LA-MED", "Medak Local Authorities", "MLC_LOCAL_AUTHORITIES", "Medak", 1],
  ["MLC-LA-NZB", "Nizamabad Local Authorities", "MLC_LOCAL_AUTHORITIES", "Nizamabad", 1],
  ["MLC-LA-ADB", "Adilabad Local Authorities", "MLC_LOCAL_AUTHORITIES", "Adilabad", 1],
  ["MLC-LA-KRM", "Karimnagar Local Authorities", "MLC_LOCAL_AUTHORITIES", "Karimnagar", 2],
  ["MLC-LA-WGL", "Warangal Local Authorities", "MLC_LOCAL_AUTHORITIES", "Warangal", 1],
  ["MLC-LA-KMM", "Khammam Local Authorities", "MLC_LOCAL_AUTHORITIES", "Khammam", 1],
  ["MLC-LA-NLG", "Nalgonda Local Authorities", "MLC_LOCAL_AUTHORITIES", "Nalgonda", 1],
  ["MLC-GRAD-MRH", "Mahbubnagar-Ranga Reddy-Hyderabad Graduates", "MLC_GRADUATES", "Mahbubnagar, Ranga Reddy, Hyderabad", 1],
  ["MLC-GRAD-MNAK", "Medak-Nizamabad-Adilabad-Karimnagar Graduates", "MLC_GRADUATES", "Medak, Nizamabad, Adilabad, Karimnagar", 1],
  ["MLC-GRAD-WKN", "Warangal-Khammam-Nalgonda Graduates", "MLC_GRADUATES", "Warangal, Khammam, Nalgonda", 1],
  ["MLC-TEACH-MRH", "Mahbubnagar-Ranga Reddy-Hyderabad Teachers", "MLC_TEACHERS", "Mahbubnagar, Ranga Reddy, Hyderabad", 1],
  ["MLC-TEACH-MNAK", "Medak-Nizamabad-Adilabad-Karimnagar Teachers", "MLC_TEACHERS", "Medak, Nizamabad, Adilabad, Karimnagar", 1],
  ["MLC-TEACH-WKN", "Warangal-Khammam-Nalgonda Teachers", "MLC_TEACHERS", "Warangal, Khammam, Nalgonda", 1]
];

async function upsertJurisdiction(db, typeId, typeCode, record) {
  const existingRows = await db.query(
    `SELECT id, name, code FROM jurisdictions WHERE jurisdiction_type_id = $1 AND is_active = true FOR UPDATE`,
    [typeId]
  );
  const existing = existingRows.rows.find(item =>
    item.code === record.code || normalizedName(item.name) === normalizedName(record.name)
  );
  const metadata = JSON.stringify(record.metadata || {});

  if (existing) {
    const result = await db.query(
      `
        UPDATE jurisdictions
        SET parent_jurisdiction_id = $2, name = $3, code = $4,
            state_code = 'TG', seat_reservation = $5,
            source_name = $6, source_reference = $7,
            verification_status = 'SOURCE_VERIFIED',
            metadata = metadata || $8::jsonb, is_active = true, updated_at = now()
        WHERE id = $1 RETURNING id
      `,
      [existing.id, record.parentId, record.name, record.code, record.reservation, CEO_SOURCE, CEO_REFERENCE, metadata]
    );
    return result.rows[0].id;
  }

  const result = await db.query(
    `
      INSERT INTO jurisdictions (
        jurisdiction_type_id, parent_jurisdiction_id, name, code, state_code,
        seat_reservation, source_name, source_reference, verification_status, metadata
      ) VALUES ($1, $2, $3, $4, 'TG', $5, $6, $7, 'SOURCE_VERIFIED', $8::jsonb)
      RETURNING id
    `,
    [typeId, record.parentId, record.name, record.code, record.reservation, CEO_SOURCE, CEO_REFERENCE, metadata]
  );
  return result.rows[0].id;
}

async function importLegislative(db) {
  const typesResult = await db.query(`SELECT id, code FROM jurisdiction_types WHERE is_active = true`);
  const types = new Map(typesResult.rows.map(row => [row.code, row.id]));
  for (const required of ["PARLIAMENTARY", "ASSEMBLY", "MLC_LOCAL_AUTHORITIES", "MLC_GRADUATES", "MLC_TEACHERS"]) {
    if (!types.has(required)) throw new Error(`Missing jurisdiction type ${required}`);
  }

  const pcIds = new Map();
  const pcByAssembly = new Map();
  for (const [number, name, reservation, assemblies] of parliamentaryDefinitions) {
    const id = await upsertJurisdiction(db, types.get("PARLIAMENTARY"), "PARLIAMENTARY", {
      parentId: null, name, code: `PC-${String(number).padStart(2, "0")}`, reservation,
      metadata: { office: "MP", seats: 1, assembly_numbers: assemblies }
    });
    pcIds.set(number, id);
    for (const assemblyNumber of assemblies) pcByAssembly.set(assemblyNumber, id);
  }

  for (let index = 0; index < assemblyNames.length; index += 1) {
    const number = index + 1;
    await upsertJurisdiction(db, types.get("ASSEMBLY"), "ASSEMBLY", {
      parentId: pcByAssembly.get(number),
      name: assemblyNames[index],
      code: `AC-${String(number).padStart(3, "0")}`,
      reservation: scAssembly.has(number) ? "SC" : stAssembly.has(number) ? "ST" : "GENERAL",
      metadata: { office: "MLA", seats: 1, assembly_number: number }
    });
  }

  for (const [recordCode, name, typeCode, extent, seats] of mlcDefinitions) {
    await upsertJurisdiction(db, types.get(typeCode), typeCode, {
      parentId: null, name, code: recordCode, reservation: null,
      metadata: {
        office: "MLC", seats, legacy_geographic_extent: extent,
        crosswalk_status: "CURRENT_DISTRICT_SUCCESSOR_MAPPING_REQUIRED"
      }
    });
  }
}

async function validationSummary(db) {
  const result = await db.query(`
    SELECT 'Administrative source units' AS metric, COUNT(*)::int AS value
      FROM geo_units WHERE source_name = $1 AND geo_type IN ('STATE','DISTRICT','MANDAL','VILLAGE')
    UNION ALL SELECT 'Legislative constituencies', COUNT(*)::int
      FROM jurisdictions WHERE source_name = $2
    UNION ALL SELECT 'Local bodies', COUNT(*)::int FROM local_bodies WHERE is_active = true
    UNION ALL SELECT 'Local electoral areas', COUNT(*)::int FROM local_body_electoral_areas WHERE is_active = true
    UNION ALL SELECT 'Local body mappings', COUNT(*)::int FROM local_body_geo_mapping WHERE is_active = true
    UNION ALL SELECT 'Local area mappings', COUNT(*)::int FROM local_body_area_geo_mapping WHERE is_active = true
    UNION ALL SELECT 'Review-required local bodies', COUNT(*)::int
      FROM local_bodies WHERE is_active = true AND verification_status LIKE '%REVIEW_REQUIRED%'
  `, [SOURCE_NAME, CEO_SOURCE]);
  return result.rows;
}

async function assertImportedCounts(db) {
  const result = await db.query(`
    SELECT
      (SELECT COUNT(*)::int FROM geo_units
        WHERE source_name = $1 AND geo_type IN ('STATE','DISTRICT','MANDAL','VILLAGE')) AS administrative,
      (SELECT COUNT(*)::int FROM jurisdictions WHERE source_name = $2) AS legislative,
      (SELECT COUNT(*)::int FROM local_bodies WHERE source_name = $1 AND is_active = true) AS local_bodies,
      (SELECT COUNT(*)::int FROM local_body_electoral_areas WHERE source_name = $1 AND is_active = true) AS areas
  `, [SOURCE_NAME, CEO_SOURCE]);
  const counts = result.rows[0];
  assertCount("Imported administrative units", counts.administrative, 12098);
  assertCount("Imported legislative constituencies", counts.legislative, 152);
  assertCount("Imported local bodies", counts.local_bodies, 9181);
  assertCount("Imported sourced electoral areas", counts.areas, 11819);
}

async function createBackup(db) {
  const suffix = new Date().toISOString().replace(/[^0-9]/g, "").slice(0, 14);
  const schema = `geography_backup_${suffix}`;
  const tables = [
    "geo_units",
    "jurisdictions",
    "jurisdiction_geo_mapping",
    "local_bodies",
    "local_body_electoral_areas",
    "local_body_geo_mapping",
    "local_body_area_geo_mapping"
  ];

  await db.query(`CREATE SCHEMA ${schema}`);
  for (const table of tables) {
    await db.query(`CREATE TABLE ${schema}.${table} AS TABLE public.${table}`);
  }
  return schema;
}

async function main() {
  const args = argumentsFrom(process.argv.slice(2));
  const adminFile = requiredArgument(args, "--admin");
  const localBodyFile = requiredArgument(args, "--local-body");
  const apply = args.get("--apply") === true;
  const sources = loadSources(adminFile, localBodyFile);

  console.table({
    states: sources.states.size,
    districts: sources.districts.size,
    mandals: sources.mandals.size,
    villages: sources.villages.size,
    gramPanchayatSourceRows: sources.gramPanchayatRows.length,
    uniqueGramPanchayats: sources.gramPanchayats.size,
    urbanBodies: sources.urbanBodies.size,
    urbanWards: sources.urbanWards.size,
    missingGpAssignments: sources.gpVillages.filter(row => !code(row.Gram_Panchayat_Code)).length
  });

  if (!apply) {
    console.log("Dry run passed. Re-run with --apply to write one database transaction.");
    return;
  }

  const { getDb } = await import("./postgres.js");
  const db = await getDb();
  try {
    await db.query("BEGIN");
    const backupSchema = await createBackup(db);
    console.log(`Pre-import backup schema: ${backupSchema}`);
    const geoIds = await importAdministrative(db, sources);
    const localResult = await importLocalBodies(db, sources, geoIds);
    await importLegislative(db);
    await assertImportedCounts(db);
    const summary = await validationSummary(db);
    console.table(summary);
    console.log(`Villages without supplied GP assignment: ${localResult.missingGpMappings}`);
    console.log("Not imported because source rows are absent: ZPTC, MPTC and Gram Panchayat wards.");
    await db.query("COMMIT");
    console.log("Telangana geography import committed.");
  } catch (error) {
    await db.query("ROLLBACK");
    throw error;
  } finally {
    await db.end();
  }
}

main().catch(error => {
  console.error("Telangana geography import failed:", error.message);
  process.exit(1);
});
