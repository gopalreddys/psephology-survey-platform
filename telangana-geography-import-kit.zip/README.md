# Telangana geography import

Copy `import-telangana-geography.js` to the backend `src/db` directory and place the two source workbooks outside the application source tree.

Validate without writing:

```bash
node src/db/import-telangana-geography.js \
  --admin /path/Telangana_Administrative_Hierarchy.xlsx \
  --local-body /path/Telangana_LocalBody_Election_Structure.xlsx
```

Apply after the dry run succeeds:

```bash
node src/db/import-telangana-geography.js \
  --admin /path/Telangana_Administrative_Hierarchy.xlsx \
  --local-body /path/Telangana_LocalBody_Election_Structure.xlsx \
  --apply
```

The write first snapshots all seven geography tables into a timestamped backup schema, then runs in one transaction and rolls back on an error. Re-running performs idempotent updates. ZPTC, MPTC and Gram Panchayat ward rows are intentionally not generated because the source workbooks state that those datasets were not supplied.
